/// <reference path="browser/ambient/es6-shim/index.d.ts" />
/// <reference path="browser/definitions/moment/index.d.ts" />
