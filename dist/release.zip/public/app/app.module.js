System.register(['@angular/core', '@angular/platform-browser', '@angular/forms', '@angular/router', './app.component', './login/login.component', './forgot/forgot.component', './reset/reset.component', './create/create.component', './pages/pages.component', './files/files.component', './users/users.component', './menus/menus.component', './forms/forms.component', './settings/settings.component', './submissions/submissions.component', './galleries/galleries.component', './edit/edit.component', '@angular/http', './app.routes', 'ng2-translate/ng2-translate', './shared/pipes/time-ago.pipe'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, platform_browser_1, forms_1, router_1, app_component_1, login_component_1, forgot_component_1, reset_component_1, create_component_1, pages_component_1, files_component_1, users_component_1, menus_component_1, forms_component_1, settings_component_1, submissions_component_1, galleries_component_1, edit_component_1, http_1, app_routes_1, ng2_translate_1, time_ago_pipe_1, http_2;
    var AppModule;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            },
            function (forms_1_1) {
                forms_1 = forms_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (app_component_1_1) {
                app_component_1 = app_component_1_1;
            },
            function (login_component_1_1) {
                login_component_1 = login_component_1_1;
            },
            function (forgot_component_1_1) {
                forgot_component_1 = forgot_component_1_1;
            },
            function (reset_component_1_1) {
                reset_component_1 = reset_component_1_1;
            },
            function (create_component_1_1) {
                create_component_1 = create_component_1_1;
            },
            function (pages_component_1_1) {
                pages_component_1 = pages_component_1_1;
            },
            function (files_component_1_1) {
                files_component_1 = files_component_1_1;
            },
            function (users_component_1_1) {
                users_component_1 = users_component_1_1;
            },
            function (menus_component_1_1) {
                menus_component_1 = menus_component_1_1;
            },
            function (forms_component_1_1) {
                forms_component_1 = forms_component_1_1;
            },
            function (settings_component_1_1) {
                settings_component_1 = settings_component_1_1;
            },
            function (submissions_component_1_1) {
                submissions_component_1 = submissions_component_1_1;
            },
            function (galleries_component_1_1) {
                galleries_component_1 = galleries_component_1_1;
            },
            function (edit_component_1_1) {
                edit_component_1 = edit_component_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
                http_2 = http_1_1;
            },
            function (app_routes_1_1) {
                app_routes_1 = app_routes_1_1;
            },
            function (ng2_translate_1_1) {
                ng2_translate_1 = ng2_translate_1_1;
            },
            function (time_ago_pipe_1_1) {
                time_ago_pipe_1 = time_ago_pipe_1_1;
            }],
        execute: function() {
            AppModule = (function () {
                function AppModule() {
                }
                AppModule = __decorate([
                    core_1.NgModule({
                        declarations: [app_component_1.AppComponent, login_component_1.LoginComponent, forgot_component_1.ForgotComponent, reset_component_1.ResetComponent, create_component_1.CreateComponent, pages_component_1.PagesComponent, files_component_1.FilesComponent, users_component_1.UsersComponent, menus_component_1.MenusComponent, forms_component_1.FormsComponent, settings_component_1.SettingsComponent, submissions_component_1.SubmissionsComponent, galleries_component_1.GalleriesComponent, edit_component_1.EditComponent, time_ago_pipe_1.TimeAgoPipe],
                        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, router_1.RouterModule, app_routes_1.routing, http_1.HttpModule, ng2_translate_1.TranslateModule.forRoot()],
                        bootstrap: [app_component_1.AppComponent],
                        providers: [
                            http_2.HTTP_PROVIDERS
                        ]
                    }), 
                    __metadata('design:paramtypes', [])
                ], AppModule);
                return AppModule;
            }());
            exports_1("AppModule", AppModule);
        }
    }
});

//# sourceMappingURL=app.module.js.map
